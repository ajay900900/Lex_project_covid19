import ast
from collections import OrderedDict

def combine_dicts(file_path):
    merged_dict = OrderedDict()
    order_of_countries = []

    with open(file_path, 'r') as file:
        for line in file:
            data = ast.literal_eval(line)
            for country, files in data.items():
                if country not in merged_dict:
                    merged_dict[country] = OrderedDict.fromkeys(files)
                    order_of_countries.append(country)
                else:
                    existing_files = merged_dict[country].keys()
                    new_files = [file for file in files if file not in existing_files]
                    merged_dict[country].update(OrderedDict.fromkeys(new_files))

    return merged_dict, order_of_countries

file_path = 'file_mapping.txt'
result, order_of_countries = combine_dicts(file_path)
for country, files in result.items():
    # print(f"{country}: {list(files.keys())}")
    for f in files:
   	    print(f)

# # User input for country name
# user_country = input("Enter a country name: ")

# # Check if the entered country exists in the dictionary
# if user_country in result:
#     print(f"The files for {user_country} are: {list(result[user_country].keys())}")
# else:
#     print("Enter a valid country name.")

