import os
import calendar

start="10-4-2020"
end="21-2-2022"
print("Input Date Range:")
start = input()
end = input()
start_day, start_month, start_year = map(int, start.split('-'))
end_day, end_month, end_year = map(int, end.split('-'))
os.environ['START_DATE'] = f"{start_day}-{start_month}-{start_year}"
os.environ['END_DATE'] = f"{end_day}-{end_month}-{end_year}"
makefile_directory = '../Module_2_1to2/module_3_2_news'
os.chdir(makefile_directory)
os.system('make -f Makefile')
