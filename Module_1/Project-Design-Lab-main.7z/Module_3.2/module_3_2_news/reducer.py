import sys

for line in sys.stdin:
    if(len(line)>0):
        print(line)

