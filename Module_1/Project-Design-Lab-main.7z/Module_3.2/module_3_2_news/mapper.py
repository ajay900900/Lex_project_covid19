import sys
import calendar
file_name=sys.argv[1]
start_date=sys.argv[2]
end_date=sys.argv[3]
print(start_date,end_date)
start_day, start_month, start_year = map(int, start_date.split('-'))
end_day, end_month, end_year = map(int, end_date.split('-'))
month_names = list(calendar.month_name)
with open(file_name, 'r', encoding='latin-1') as fp:
	year=file_name.split("_")[1]
	year=int(year)
	month=file_name.split("_")[0]
	month=month.split("/")[2]
	for line in fp:
		date, content= line.split('::')
		date=date.split(" ")
		if(year==start_year and month_names.index(month)==start_month and int(date[0])<int(start_day)):
			continue
		if(year==end_year and month_names.index(month)==end_month and int(date[0])>int(end_day)):
			continue
		print(" ".join(date),year,"::",content)
	
