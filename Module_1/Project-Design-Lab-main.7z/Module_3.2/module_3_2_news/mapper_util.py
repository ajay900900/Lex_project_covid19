import calendar
import os

def generate_files(start_date, end_date):
    start_day, start_month, start_year = map(int, start_date.split('-'))
    end_day, end_month, end_year = map(int, end_date.split('-'))
    month_names = list(calendar.month_name)
    file_paths = []
    for year in range(start_year, end_year+1):
        for month_name in month_names[1:]:
            if(year==start_year):
                if(month_names.index(month_name)<start_month):
                    continue
            if(year==end_year):
                if(month_names.index(month_name)>end_month):
                    break
            month_number = month_names.index(month_name) + start_month
            file_paths.append(f"{month_name}_{year}_news.txt")
    return file_paths

if __name__ == "__main__":
    start_date = os.environ.get("START_DATE")
    end_date = os.environ.get("END_DATE")

    file_paths = generate_files(start_date, end_date)
    print("\n".join(file_paths))
