import sys
import calendar
file_name=sys.argv[1]
with open(file_name, 'r', encoding='latin-1') as fp:
	# year=file_name.split("_")[1]
	# year=int(year)
	# month=file_name.split("_")[0]
	# month=month.split("/")[2]
	for line in fp:
		try:
			date, content= line.split('::')
			print(date,'::',content)
		except ValueError:
			continue
