####SaveCountries

import re

# Initialize an empty dictionary to store regions and countries
country_dict = {}

fp = open('worldometers_countrylist.txt', 'r').read()

fp = re.sub(r":", "", fp)
fp = re.sub(r"-+", "START", fp)
fp = fp.replace("\n\n", "\nEND\n")
fp = fp+"END"

fp = fp.split("\n")

PreDefinedRegions = ["Europe","North America","Asia","South America","Africa","Oceania"]

countryBoarder = False
CurrentRegion = ""
for line in fp:
	temp = line.strip()
	if temp in PreDefinedRegions:
		country_dict[temp] = []
		CurrentRegion = temp
	elif temp == "START":
		countryBoarder = True
		continue
	elif temp == "END":
		countryBoarder = False
	
	if(countryBoarder == True):
		temp = temp.replace(" ","-")
		country_dict[CurrentRegion].append(temp)

MainURL = "https://www.worldometers.info/coronavirus/"

URLs = {}
URLs["MainPage"] = MainURL

import os
import ply.lex as lex
import ply.yacc as yacc
from urllib.request import Request, urlopen

for continent, countries in country_dict.items():
	for country in countries:
		URLs[country] = MainURL+"/country/"+country+"/"

for pageName, url in URLs.items():
	htmlFile = pageName + ".html"
	req = Request(url,headers ={'User-Agent':'Mozilla/5.0'})
	webpage = urlopen(req).read()
	mydata = webpage.decode("utf8")
	f=open(htmlFile,'w',encoding="utf-8")
	f.write(mydata)
	f.close

