import ply.lex as lex
import ply.yacc as yacc

tableheader_list = []
rows_list = []
WorldData = {}
Count8 = 0

### DEFINING TOKENS ###
tokens = ('BEGINTABLE', 'SKIPSPACE','OPENTHEAD','CLOSETHEAD', 'BREAK',
'OPENTABLE', 'CLOSETABLE', 'OPENROW', 'CLOSEROW',
'OPENHEADER', 'CLOSEHEADER', 'OPENHREF', 'CLOSEHREF',
'CONTENT',  'OPENDATA', 'CLOSEDATA' )
t_ignore = '\t'

###############Tokenizer Rules################
def t_BEGINTABLE(t):
    r'<table[^>]*id="main_table_countries_yesterday"[^>]*>'
    return t

def t_OPENTABLE(t):
    r'<tbody[^>]*>'
    return t

def t_CLOSETABLE(t):
    r'</tbody[^>]*>'
    return t

def t_OPENROW(t):
    r'<tr[^>]*>'
    return t

def t_CLOSEROW(t):
    r'</tr[^>]*>'
    return t

def t_OPENTHEAD(t):
    r'<thead>'
    return t

def t_CLOSETHEAD(t):
    r'</thead>'
    return t

def t_OPENHEADER(t):
    r'<th[^>]*>'
    return t

def t_CLOSEHEADER(t):
    r'</th[^>]*>'
    return t

def t_OPENHREF(t):
    r'<a[^>]*>'
    return t

def t_CLOSEHREF(t):
    r'</a[^>]*>'
    return t

def t_OPENDATA(t):
    r'<td[^>]*>'
    return t

def t_CLOSEDATA(t):
    r'</td[^>]*>'
    return t

def t_BREAK(t):
    r'<br\s*/>'
    pass   # we used it just didn't print
    
def t_CONTENT(t):
    r'[A-Za-z0-9, .,\'-0-9/():– #]+'
    return t

def t_SKIPSPACE(t):  # Not TRUE :: WARNING: Token 'SKIPSPACE' defined, but not used, we used it, don't remove
    r'\s+'
    pass	# we used it just didn't print

def t_error(t):
    t.lexer.skip(1)
####################################################################################################################################################################################################
											#GRAMMAR RULES
def p_start(p):
    '''start : table'''
    p[0] = p[1]

def p_handleheader(p):
    '''handleheader : OPENHEADER content CLOSEHEADER handleheader
    		    | empty'''
    if len(p) > 2:
        tableheader_list.append(p[2])
    
def p_dataCell(p):
    '''dataCell : OPENDATA content CLOSEDATA dataCell
    		| OPENDATA content CLOSEDATA content dataCell
    		| empty'''
    
    newData = ""
    if len(p) >= 4:
        newData = p[2]
        if ( len(p) == 5 and p[4] is not None):
            newData += p[4]
    rows_list.append(newData)  
        
def p_handlerow(p):
    '''handlerow : OPENROW dataCell CLOSEROW'''
    
    global rows_list, Count8, WorldData
    
    if(Count8 < 8):
    	rows_list = rows_list[7:-2]
    	rows_list.reverse()
    	rows_list.pop(7)
    	rows_list.pop(7)
    	continent = rows_list[len(rows_list)-1]
    	rows_list = rows_list[:10]
    	WorldData[continent] = rows_list
    	Count8 += 1
    else:
    	rows_list.reverse()
    	try:
    		rows_list[1] = rows_list[1].split(">")[1]
    	except:
    		rows_list[1] = rows_list[1].split("font-style:italic")[1]
    		rows_list[1] = rows_list[1].split("/span")[0]
    	try:
    		rows_list[14] = rows_list[14].split(">")[1]
    	except:
    		pass
    	rows_list = [item.strip() if item is not None else None for item in rows_list]
    	country = rows_list[1]
    	rows_list = rows_list[2:]
    	rows_list.pop(7)
    	rows_list.pop(7)
    	rows_list = rows_list[:10]
    	# changing coloumn order for queries
    	temp = []
    	temp.append(rows_list[0])
    	temp.append(rows_list[6])
    	temp.append(rows_list[2])
    	temp.append(rows_list[4])
    	temp.append(rows_list[8])
    	temp.append(rows_list[7])
    	temp.append(rows_list[9])
    	temp.append(rows_list[1])
    	temp.append(rows_list[3])
    	temp.append(rows_list[5])
    	WorldData[country] = temp

    rows_list = []
    

def p_handlerowrecursion(p):
    '''handlerowrecursion : handlerow handlerowrecursion
    			  | empty'''
    with open ("yesterday.txt", "w") as file:
    	for key, value in WorldData.items():
    		file.write( f"{key}:: {value}\n")   
    exit()
    
def p_tableheader(p):
    '''tableheader : OPENTHEAD OPENROW handleheader CLOSEROW CLOSETHEAD '''
    tableheader_list.reverse()
    #print(tableheader_list)
    #exit()
    
def p_handletable(p):
    '''handletable : OPENTABLE handlerowrecursion CLOSETABLE handletable
    		    | empty '''
			
def p_table(p):
    '''table : BEGINTABLE tableheader handletable '''

def p_empty(p):
    '''empty :'''
    pass

def p_content(p):
    '''content : CONTENT content
    	       | OPENHREF content CLOSEHREF content
               | empty'''
    if len(p) > 2:
        if p[2] is not None:
            p[0] = p[1] + " "+p[2]  # Concatenate content if it exists
            
        else:
            p[0] = p[1]  # Set p[0] to the content if it exists
        
    elif len(p) > 1:
        p[0] = p[1]  # Set p[0] to the content if it exists
    else:
        p[0] = ""  # Set p[0] to an empty string if there is no content
    
        
def p_error(p):
    print(tableheader_list, rows_list)
    print(p)
    pass

#########DRIVER FUNCTION#######
def main():
    file_obj = open('covid19.html', 'r', encoding="utf-8")

    data = file_obj.read()
    lexer = lex.lex()
    lexer.input(data)
    '''
    for tok in lexer:
            print (tok)
    exit()
    '''
    parser = yacc.yacc()
    parser.parse(data)
    file_obj.close()

if __name__ == '__main__':
    main()
