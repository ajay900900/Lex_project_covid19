import os
import subprocess
clear_command = 'cls' if os.name == 'nt' else 'clear'
while True:
    print("2. Scrape News and Responses during Covid19")
    print("3. Get News between A time Range")
    print("4. Get Responses data between a Time Range")
    print("5. Exit")
    
    response = input("Please select an option (1/2/3/4): ")
    
    if response == '1':
    	pass
        
        
    elif response == '2':
        subprocess.run(["python3", "../Module_2_1to2/driver.py"])
        # os.system(clear_command)
        print("done")
    elif response == '3':
        subprocess.run(["python3", "../Module_2_1to2/module_3_2_news/driver.py"])
    elif response == '4':
        subprocess.run(["python3", "../Module_2_1to2/module_3_2_res/driver.py"])
    elif response == '5':
        exit()
    else:
        print("Invalid option. Please try again.")
