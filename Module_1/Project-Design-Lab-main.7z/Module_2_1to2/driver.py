import os
import subprocess
import ply.lex as lex
import ply.yacc as yacc
import datetime
from collections import defaultdict

extracted_data = defaultdict(list)

###DEFINING TOKENS###
tokens = ('BEGIN','CONTENT','END','OPEN_H3','CLOSE_H3')
t_ignore = ' \t'
#####################
# t_OPEN_UL= r'<ul.*?>'
# t_CLOSE_UL= r'</ul.*?>'
# t_OPEN_LI= r'<li.*?>'
# t_CLOSE_LI= r'</li.*?>'
t_OPEN_H3= r'<h3.*?>'
t_CLOSE_H3= r'</h3.*?>'
# t_OPEN_P= r'<p.*?>'
# t_CLOSE_P= r'</p.*?>'

###############Tokenizer Rules################
def t_BEGIN(t):
    r'<div.id="siteSub".class="noprint">From.Wikipedia,.the.free.encyclopedia</div>'
    return t

def t_END(t):
    r'<h2[^>]*><span.class="mw-headline".id="See_also">See.also</span>.*?<\/h2>|<h2[^>]*><span.class="mw-headline".id="Summary">Summary</span>.*?<\/h2>'
    return t

def t_CONTENT(t):
    r'[A-Za-z0-9, .,\'-0-9/():–;]+'
    return t

def t_ignore_TAGS(t):
    r'<h4>|</h4>|<i>|</i>|</b>|<b>|<ul>|</ul>|<li>|</li>|</p>|<p>|<h2[^>]*>.*?<\/h2>|<img.*?>|<table.*?>.*?</table>|<style.*?>.*?</style>|<figure[^>]*>.*?<\/figure>|<script.*?>.*?</script>|<sup.*?>.*?</sup>|<span.*?>|</span>|<a.href.*?>|</a>|<span.class="mw-editsection">.*?]</span></span>'
    pass

def t_ignnore_situation_report(t):
    r'<b>WHO</b>Situation.Report.\(\d+\)|<b>WHO</b>Situation.Report.\(\d+\):|<b>WHO</b>Situation.Report.\(\d+\);'
    pass

def t_error(t):
    t.lexer.skip(1)
####################################################################################################################################################################################################
def p_start(p):
    '''start : table'''
    p[0] = p[1]

def p_skiptag(p):
    '''skiptag : CONTENT skiptag
               | empty'''

def p_table(p):
    '''table : BEGIN skiptag data skiptag END'''
    p[0] = p[3]

def p_header(p):
    '''header : OPEN_H3 CONTENT content CLOSE_H3'''
    p[0]=p[2]

def p_data(p):
    '''data : data header content
            | header content'''
    global extracted_data

    if(len(p)==3):
        if(p[1] not in ['Background','Timeline']):
            extracted_data[p[1]].append(p[2])
    else:
        if(p[2] not in ['Background','Timeline']):
            extracted_data[p[2]].append(p[3])
        

def p_empty(p):
    '''empty :'''
    pass

def p_content(p):
    '''content : CONTENT content
               | empty'''
    if len(p) == 3:
        p[0] = p[1] + p[2]
    else:
        p[0] = ""

 
def p_error(p):
    pass

###################DRIVER CODE################################
def main():
    directory = "../Module_2_1to2/Downloaded-Webpages-news"  # Replace "/path/to/directory" with the desired directory path
    if not os.path.exists(directory):
        os.makedirs(directory)
    directory = "../Module_2_1to2/Downloaded-Webpages-responses"  # Replace "/path/to/directory" with the desired directory path
    if not os.path.exists(directory):
        os.makedirs(directory)
    directory = "../Module_2_1to2/News"  # Replace "/path/to/directory" with the desired directory path
    if not os.path.exists(directory):
        os.makedirs(directory)
    directory = "../Module_2_1to2/Responses"  # Replace "/path/to/directory" with the desired directory path
    if not os.path.exists(directory):
        os.makedirs(directory)
    month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    for year in [2020,2021,2022]:
        for m in month:
            extracted_data.clear()
            name=f"{m}_{year}"
            url="https://en.wikipedia.org/wiki/Timeline_of_the_COVID-19_pandemic_in_"+name
            subprocess.run(["python3", "../Module_2_1to2/webpage_download_mod2.py", f"../Module_2_1to2/Downloaded-Webpages-news/{name}.html", url])
            file_obj= open(f"../Module_2_1to2/Downloaded-Webpages-news/{name}.html",'r',encoding="utf-8")
            data=file_obj.read()
            lexer = lex.lex()
            lexer.input(data)
            # for tok in lexer:
            #     print(tok)
            parser = yacc.yacc()
            parser.parse(data)

            with open(f'../Module_2_1to2/News/{name}_news.txt', 'w') as file:
                for date, content in extracted_data.items():
                    file.write(f'{date}:: {" ".join(map(str, content))}\n')
            print(f"extracted news: {m} {year}")

            file_obj.close()
    url="https://en.wikipedia.org/wiki/Timeline_of_the_COVID-19_pandemic_in_2023"
    subprocess.run(["python3", "../Module_2_1to2/webpage_download_mod2.py", f"../Module_2_1to2/Downloaded-Webpages-news/2023_news.html", url])
    url="https://en.wikipedia.org/wiki/Timeline_of_the_COVID-19_pandemic_in_2024"
    subprocess.run(["python3", "../Module_2_1to2/webpage_download_mod2.py", f"../Module_2_1to2/Downloaded-Webpages-news/2024_news.html", url])       
    subprocess.run(["python3", "../Module_2_1to2/2023_2024_util.py"])
    month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    for year in [2020,2021,2022]:
        for m in month:
            extracted_data.clear()
            if(year==2022 and m in ['November', 'December']):
                continue
            name=f"{m}_{year}"
            url="https://en.wikipedia.org/wiki/Responses_to_the_COVID-19_pandemic_in_"+name
            subprocess.run(["python3", "../Module_2_1to2/webpage_download_mod2.py", f"../Module_2_1to2/Downloaded-Webpages-responses/{name}.html", url])
            file_obj= open(f"../Module_2_1to2/Downloaded-Webpages-responses/{name}.html",'r',encoding="utf-8")
            data=file_obj.read()
            lexer = lex.lex()
            lexer.input(data)
            # for tok in lexer:
            #     print(tok)
            parser = yacc.yacc()
            parser.parse(data)

            with open(f'../Module_2_1to2/Responses/{name}_response.txt', 'w') as file:
                for date, content in extracted_data.items():
                    file.write(f'{date}:: {" ".join(map(str, content))}\n')

            file_obj.close()
            print(f"extracted response: {m} {year}")


if __name__ == "__main__":
    main()

