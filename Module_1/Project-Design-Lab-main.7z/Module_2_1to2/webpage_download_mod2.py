import sys
from urllib.request import Request, urlopen
name=sys.argv[1]
webpage=sys.argv[2]
req = Request(webpage,headers ={'User-Agent':'Mozilla/5.0'})
webpage = urlopen(req).read()
mydata = webpage.decode("utf8")
f=open(name,'w',encoding="utf-8")
f.write(mydata)
f.close
